<?php

if(!isset($_SESSION)) session_start();

if(!isset($_SESSION['login']['auth'])) {
	session_destroy();
	
	header("Location: login.php");
}

?>
<!DOCTYPE html>
<!--
	Template Name: Lacegant
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html>
	<head>
		<title>GYCam | Contact</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
		<link href="../layout/styles/style.css" rel="stylesheet" type="text/css" media="all">
	</head>
	<body id="top">
	<?php

		$pageName = "contact";
		$urlimage = "background-image:url('../images/demo/backgrounds/02.jpg');";
		$home = "home.php";
		$gallery = "gallery.php";
		$contact = "contact.php";
		$profile = "profile.php";
		$despesas = "../despesas.php";
		$sair = "sair.php";

		// HEADER
		include_once("../fragments/header.php"); 
		// MENU
		include_once("../fragments/menu.php"); 
		// 	LOCATION
		include_once("../fragments/location.php"); 

	?>
		<div class="wrapper row3">
			<main class="hoc container clear"> 
				<div class="content"> 
					<div id="comments">
						<h2>Nós envie uma mensagem</h2>
						<form action="agradece.php" method="post">
							<div class="one_half first">
								<label for="name"> Seu Nome <span>*</span></label>
								<input type="text" name="name" id="name" value="" size="22" required>
							</div>
							<div class="one_half">
								<label for="email">Seu Email <span>*</span></label>
								<input type="email" name="email" id="email" value="" size="22" required>
							</div>
							<div class="hoc">
								<div class=" styled-select black rounded">
									<label for="email">Tipo de mensagem:</label>
									<select name="type">
										<option value="volvo" selected>Sugestão</option>
										<option value="audi">Elogio</option>
										<option value="saab">Reclamação</option>
										<option value="mercedes">Quero entrar no grupo</option>
										<option value="audi">Comercial</option>
									</select> 
								</div>
							</div>
							<div class="block clear">
								<label for="comment">Seu comentário:</label>
								<textarea name="comment" id="comment" cols="25" rows="10"></textarea>
							</div>
							<div>
								<input type="submit" name="submit" value="Enviar">
								&nbsp;
								<input type="reset" name="reset" value="Limpar">
							</div>
						</form>
					</div>
				</div>
				<div class="clear"></div>
			</main>
		</div>
	<?php

		// FOOTER CONTACT
		include_once("../fragments/footer-contact.php");
		// FOOTER
		include_once("../fragments/footer.php");

	?>
		<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
		<!-- JAVASCRIPTS -->
		<script src="../layout/scripts/jquery.min.js"></script>
		<script src="../layout/scripts/jquery.backtotop.js"></script>
		<script src="../layout/scripts/jquery.mobilemenu.js"></script>
		<!-- IE9 Placeholder Support -->
		<script src="../layout/scripts/jquery.placeholder.min.js"></script>
		<!-- Adição da classe ativa para pagina do menu -->
		<script>
			$("#mainav ul li:nth-child(3)").addClass("active");
		</script>
	</body>
</html>