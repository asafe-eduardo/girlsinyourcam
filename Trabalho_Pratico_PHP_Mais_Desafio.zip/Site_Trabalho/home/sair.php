<?php

session_start();

unset ($_SESSION['login']);
setcookie ("login", "", (time() - 1), "/");
session_destroy();
header ("Location: ../login.php");

?>