<?php

if(!isset($_SESSION)) session_start();

if(!isset($_SESSION['login']['auth'])) {
	session_destroy();
	
	header("Location: login.php");
}

?>

<!DOCTYPE html>
<!--
Template Name: Lacegant
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<?php
	$nome = $_POST["name"];
?>
<html>
	<head>
		<title>GYCam | Obrigado</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
		<link href="../layout/styles/style.css" rel="stylesheet" type="text/css" media="all">
	</head>
	<body id="top">
	<?php

		$pageName = "contact";
		$urlimage = "background-image:url('../images/demo/backgrounds/02.jpg');";
		$home = "home.php";
		$gallery = "gallery.php";
		$contact = "contact.php";
		$profile = "profile.php";
		$despesas = "../despesas.php";
		$sair = "sair.php";


		// HEADER
		include_once("../fragments/header.php"); 
		// MENU
		include_once("../fragments/menu.php"); 
		// 	LOCATION
		include_once("../fragments/location.php"); 

	?>
		<div class="wrapper row3">
			<main class="hoc container clear"> 
				<div class="content"> 
					<article class="center">
						<h2 class="heading">Obrigado!</h2>
						<p>Sua mensagem foi enviada Sr(a). <?php print $nome; ?> enquanto isso, veja um show de nossas garotas gratuitamente.</p>
						<footer><a class="btn" href="#">Confira</a></footer>
					</article>
      
	   
				</div>
				<div class="clear"></div>
			</main>
		</div>
	<?php

		// FOOTER CONTACT
		include_once("../fragments/footer-contact.php");
		// FOOTER
		include_once("../fragments/footer.php");

	?>

		<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
		<!-- JAVASCRIPTS -->
		<script src="../layout/scripts/jquery.min.js"></script>
		<script src="../layout/scripts/jquery.backtotop.js"></script>
		<script src="../layout/scripts/jquery.mobilemenu.js"></script>
		<!-- IE9 Placeholder Support -->
		<script src="../layout/scripts/jquery.placeholder.min.js"></script>
		<!-- Adição da classe ativa para pagina do menu -->
		<script>
			$("#mainav ul li:nth-child(3)").addClass("active");
		</script>
	</body>
</html>