<?php

if(!isset($_SESSION)) session_start();

if(!isset($_SESSION['login']['auth'])) {
	session_destroy();
	
	header("Location: login.php");
}
	


?>
<!DOCTYPE html>
<!--
Template Name: Lacegant
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html>
	<head>
		<title>Girls In Your Cam</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
		<link href="../layout/styles/style.css" rel="stylesheet" type="text/css" media="all">
	</head>
	<body id="top">

	<?php
		$msg = "<h2 class='heading font-x3'>Estamos recrutando junte-se ao nosso time de garotas</h2>";
		
		$home = "home.php";
		$gallery = "gallery.php";
		$contact = "contact.php";
		$profile = "profile.php";
		$despesas = "../despesas.php";
		$sair = "sair.php";

		// HEADER
		include_once("../fragments/header.php"); 
		// MENU
		include_once("../fragments/menu.php"); 

	?>

		<div class="wrapper bgded overlay" style="background-image:url('../images/demo/backgrounds/01.jpg');">
			<div id="pageintro" class="hoc clear"> 
				<article class="introtxt">
					<h2 class="heading">Divirta-se conosco</h2>
					<p>As garotas mais gostosas da internet direto na sua tela&hellip;</p>
					<footer><a class="btn inverse medium" href="#">Confira</a></footer>
				</article>
			</div>
		</div>
		<div class="wrapper bgded overlay coloured" style="background-image:url('../images/demo/backgrounds/02.jpg');">
			<div id="cta" class="hoc clear"> 
				<article class="center">
					<?php print $msg; ?>
					<footer>
						<ul class="nospace inline pushright">
							<li><a class="btn inverse" href="contact.php" target="_blank">Contatar</a></li>
							<li><a class="btn inverse" href="gallery.php" target="_blank">Ver galeria</a></li>
						</ul>
					</footer>
				</article>
			</div>
		</div>
		<div class="wrapper row6">
			<div class="hoc container clear"> 
				<div class="center btmspace-50">
					<h2 class="heading">Integrantes da nossa equipe</h2>
					<p class="nospace">As gatas mais lindas da web estão esperando por você</p>
				</div>
				<ul class="nospace group btmspace-50 elements">
					<li class="one_quarter first">
						<article>
							<figure><img src="../images/demo/steph.jpg" alt="">
								<figcaption>Steph Kegel</figcaption>
							</figure>
							<div class="txtwrap">
								<h6 class="heading"><a  href="../perfils/steph.php" target="_blank">A rainha das "WebCam Girls"</a></h6>
								<p>A rainha dominicana mais famosa da internet agora faz parte de nossa equipe&hellip;</p>
							</div>
						</article>
					</li>
					<li class="one_quarter">
						<article>
							<figure><img src="../images/demo/sexydea.jpg" alt="">
								<figcaption>Sexydea</figcaption>
							</figure>
							<div class="txtwrap">
								<h6 class="heading"><a href="../perfils/sexydea.php" target="_blank">A mais "Sexy"</a></h6>
								<p>A espanhola dona da "bootyland" sexydea faz parte de nossa equipe também&hellip;</p>
							</div>
						</article>
					</li>
					<li class="one_quarter">
						<article>
							<figure>
								<img src="../images/demo/dariejxo.jpg" alt="">
								<figcaption>Dariejxo</figcaption>
							</figure>
							<div class="txtwrap">
								<h6 class="heading"><a href="../perfils/dariejxo.php" target="_blank">A flor do oriente</a></h6>
								<p>Dariej a mais bela oriental da web é integrante do nosso time&hellip;</p>
							</div>
						</article>
					</li>
					<li class="one_quarter">
						<article>
							<figure>
								<img src="../images/demo/320x220.png" alt="">
								<figcaption>Seu rosto aqui</figcaption>
							</figure>
							<div class="txtwrap">
								<h6 class="heading"><a href="../perfils/unknown.php" target="_blank">Nossa nova garota</a></h6>
								<p>Nós contate e entre para nossa equipe&hellip;</p>
							</div>
						</article>
					</li>
				</ul>
				<p class="nospace center"><a class="btn small" href="#">Veja uma das nossas gatas ao vivo</a></p>
				<div class="clear"></div>
			</div>
		</div>

	<?php

		// FOOTER CONTACT
		include_once("../fragments/footer-contact.php");
		// FOOTER
		include_once("../fragments/footer.php");

	?>
		<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
		<!-- JAVASCRIPTS -->
		<script src="../layout/scripts/jquery.min.js"></script>
		<script src="../layout/scripts/jquery.backtotop.js"></script>
		<script src="../layout/scripts/jquery.mobilemenu.js"></script>
		<!-- IE9 Placeholder Support -->
		<script src="../layout/scripts/jquery.placeholder.min.js"></script>
		<!-- Adição da classe ativa para pagina do menu -->
		<script>
			$("#mainav ul li:nth-child(1)").addClass("active");
		</script>
		<script src="../layout/scripts/styles.js"></script>
	</body>
</html>