<?php

if(!isset($_SESSION)) session_start();

if(!isset($_SESSION['login']['auth'])) {
	session_destroy();
	
	header("Location: login.php");
}

?>
<!DOCTYPE html>
<!--
	Template Name: Lacegant
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html>
	<head>
		<title>GYCam | Profile</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
		<link href="../layout/styles/style.css" rel="stylesheet" type="text/css" media="all">
	</head>
	<body id="top">
	<?php

		$pageName = "profile";
		$urlimage = "background-image:url('../images/demo/backgrounds/02.jpg');";
		$home = "home.php";
		$gallery = "gallery.php";
		$contact = "contact.php";
		$profile = "profile.php";
		$despesas = "../despesas.php";
		$sair = "sair.php";

		// HEADER
		include_once("../fragments/header.php"); 
		// MENU
		include_once("../fragments/menu.php"); 
		// 	LOCATION
		include_once("../fragments/location.php"); 

	?>
		<div class="wrapper row3">
			<main class="hoc container clear"> 
				<div class="content"> 
					<div id="comments">
						<h2>Profile</h2>
						<form action="../alterar.php" method="POST">
							<div class="one_half first">
								<label for="nome"> Seu Nome <span>*</span></label>
								<input type="text" name="nome" id="nome" value="" size="22" placeholder="<?php echo  $_SESSION['login']['nome']?>" required>
							</div>
							<div class="one_half">
								<label for="email">Seu Email <span>*</span></label>
								<input type="email" name="email" id="email" value="" size="22"  placeholder="<?php echo  $_SESSION['login']['email']?>" required>
							</div>
							<div class="one_half first">
								<label for="login">Seu Login <span>*</span></label>
								<input type="text" name="login" id="login" value="" size="22"  placeholder="<?php echo  $_SESSION['login']['user']?>" required>
							</div>
							<div class="one_half first">
								<label for="senha">Sua Senha <span>*</span></label>
								<input type="password" name="senha" id="senha" value="" size="22"  placeholder="<?php echo  $_SESSION['login']['senha']?>" required>
							</div>
							<div class="one_half">
								<label for="re-senha">Confirmar Senha <span>*</span></label>
								<input type="password" name="re-senha" id="re-senha" value="" size="22" required>
							</div>
							<div class="one_half first">
								<label for="dica-senha">Dica de Senha <span>*</span></label>
								<input type="text" name="dica-senha" id="dica-senha" value="" size="22"  placeholder="<?php echo  $_SESSION['login']['dica-senha']?>" required>
							</div>
							<div class="one_half first">
								<input type="submit" name="submit" value="Enviar alteração">
								&nbsp;
								<input type="reset" name="reset" value="Limpar">
							</div>
						</form>
					</div>
				</div>
				<div class="clear"></div>
			</main>
		</div>
	<?php

		// FOOTER CONTACT
		include_once("../fragments/footer-contact.php");
		// FOOTER
		include_once("../fragments/footer.php");

	?>
		<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
		<!-- JAVASCRIPTS -->
		<script src="../layout/scripts/jquery.min.js"></script>
		<script src="../layout/scripts/jquery.backtotop.js"></script>
		<script src="../layout/scripts/jquery.mobilemenu.js"></script>
		<!-- IE9 Placeholder Support -->
		<script src="../layout/scripts/jquery.placeholder.min.js"></script>
		<!-- Adição da classe ativa para pagina do menu -->
		<script>
			$("#mainav ul li:nth-child(4)").addClass("active");
		</script>
	</body>
</html>