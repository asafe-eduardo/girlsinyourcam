<!DOCTYPE html>
<!--
Template Name: Lacegant
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html>
	<head>
		<title>GYCam | Registro</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
	</head>
	<body id="top">
		<?php

		// HEADER
		include_once("fragments/header.php"); 

		?>
		<div class="wrapper bgded">
			<main class="hoc container clear"> 
				<div class="content"> 
					<div id="comments">
						<h2>Preencha os campos para cadastro</h2>
						<form action="registro_oauth.php" method="POST">
							<div class="one_half first">
								<label for="nome">Nome: <span>*</span></label>
								<input type="text" name="nome" id="nome" value="" size="22" required>
							</div>
							<div class="one_half first">
								<label for="email">Email: <span>*</span></label>
								<input type="email" name="email" id="email" value="" size="22" required>
							</div>
							<div class="one_half first">
								<label for="login">Login: <span>*</span></label>
								<input type="text" name="login" id="login" value="" size="22" required>
							</div>
							<div class="one_half first">
								<label for="senha">Senha: <span>*</span></label>
								<input type="password" name="senha" id="senha" value="" size="22" required>
							</div>
							<div class="one_half first">
								<label for="re-senha">Confirmar Senha: <span>*</span></label>
								<input type="password" name="re-senha" id="re-senha" value="" size="22" required>
							</div>
							<div class="one_half first">
								<label for="dica-senha">Dica de senha: <span>*</span></label>
								<input type="dica-senha" name="dica-senha" id="dica-senha" value="" size="22" required>
							</div>
							<div class="one_half first">
								<input type="submit" name="cadastrar" value="Cadastrar">
								&nbsp;
								<input type="reset" name="reset" value="Limpar">
							</div>
						</form>
					</div>
				</div>
				<div class="clear"></div>
				<a href="login.php"> Voltar para tela de login</a>
			</main>
		</div>
		<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
		<!-- JAVASCRIPTS -->
		<script src="layout/scripts/jquery.min.js"></script>
		<script src="layout/scripts/jquery.backtotop.js"></script>
		<script src="layout/scripts/jquery.mobilemenu.js"></script>
		<!-- IE9 Placeholder Support -->
		<script src="layout/scripts/jquery.placeholder.min.js"></script>
	</body>
</html>