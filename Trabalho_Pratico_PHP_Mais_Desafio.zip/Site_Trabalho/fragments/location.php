<div class="wrapper bgded overlay" style="<?php print $urlimage; ?>">
  <div id="breadcrumb" class="hoc clear"> 
    <ul>
      <li><a href="#">Home</a></li>
      <li><a href="#"><?php echo $pageName?></a></li>
    </ul>
  </div>
</div>