<div class="wrapper row4">
  <footer id="footer" class="hoc clear"> 
    <div class="one_half first">
      <h6 class="title">Contatos</h6>
      <ul class="nospace linklist contact">
        <li><i class="fa fa-map-marker"></i>
          <address>
          Nome da rua &amp; Número, Cidade, Código postal
          </address>
        </li>
        <li><i class="fa fa-phone"></i> +00 (123) 456 7890<br>
          +00 (123) 456 7890</li>
        <li><i class="fa fa-fax"></i> +00 (123) 456 7890</li>
        <li><i class="fa fa-envelope-o"></i> info@domain.com</li>
      </ul>
    </div>
    <div class="one_half">
      <h6 class="title">Entre para nossa Newsletter</h6>
      <p class="btmspace-30">Digite seu nome e email e fique por dentro de todas as noticias da GYCam</p>
      <form method="post" action="#">
        <fieldset>
          <legend>Newsletter:</legend>
          <input class="btmspace-15" type="text" value="" placeholder="Nome">
          <input class="btmspace-15" type="text" value="" placeholder="Email">
          <button type="submit" value="submit">Enviar</button>
        </fieldset>
      </form>
    </div>
  </footer>
</div>