<div class="wrapper row1">
  <header id="header" class="hoc clear"> 
    <div id="logo">
      <h1><a href="#">Girls in your Cam</a></h1>
      <p>Diversão, garotas e muito mais tudo ao vivo.</p>
    </div>
  </header>
</div>