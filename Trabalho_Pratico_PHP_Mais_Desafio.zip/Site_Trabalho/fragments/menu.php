<div class="wrapper row2">
  <nav id="mainav" class="hoc clear"> 
    <ul class="clear">
      <li><a href="<?php print $home;	?>">Home</a></li>
      <li><a href="<?php print $gallery;	?>">Galeria</a></li>
	  <li><a href="<?php print $contact;	?>">Contato</a></li>
	  <li><a href="<?php print $profile;	?>">Profile</a></li>
	  <li><a href="<?php print  $despesas;	?>">Despesas</a></li>
	  <li><a href="<?php print  $sair;	?>">Sair</a></li>
    </ul>
  </nav>
</div>