		<div class="wrapper row2">
			<nav id="mainav" class="menu-ajax hoc clear"> 
				<ul class="clear">
					<li><a href="#" class="steph">steph</a></li>
					<li><a href="#" name="sexydea.php">sexydea</a></li>
					<li><a href="#" name="dariejxo.php">dariejxo</a></li>
					<li><a href="#" name="unknow.php">info</a></li>
				</ul>
			</nav>
		<div>