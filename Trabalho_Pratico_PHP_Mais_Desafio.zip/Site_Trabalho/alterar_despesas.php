<?php
	
	require "init.php";
	session_start();
	
	$id = $_GET['id_despesa'];
	
	$Despesa = new Despesa;
	$Despesa->retornaDespesaPorId($id);
	
	
?>
<!DOCTYPE html>
<!--
Template Name: Lacegant
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html>
	<head>
		<title>GYCam | Alterar</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
		<link href="layout/styles/style.css" rel="stylesheet" type="text/css" media="all">
	</head>
	<body id="top">
		<?php

		$pageName = "Despesas > Alterar";
		$urlimage = "background-image:url('images/demo/backgrounds/02.jpg');";
		
		$home = "home/home.php";
		$gallery = "home/gallery.php";
		$contact = "home/contact.php";
		$profile = "home/profile.php";
		$despesas = "despesas.php";
		$sair = "home/sair.php";

		// HEADER
		include_once("fragments/header.php"); 
		// MENU
		include_once("fragments/menu.php"); 
		// 	LOCATION
		include_once("fragments/location.php"); 

		?>
		<div class="wrapper row3">
			<main class="hoc container clear"> 
				<div class="content"> 
					<center><h1>Alterar despesa</h1></center>
					<div id="comments">
						<h2>Compra / Vender</h2>
						<form action="alterar_despesas_oauth.php" method="POST">
							<div class="one_half first">
								<label for="titulo">Titulo da Despesa<span>*</span></label>
								<input type="text" name="titulo" id="titulo" placeholder="<?php echo $_SESSION['despesas']['titulo']; ?>" size="22" required>
							</div>
							<div class="one_half">
								<label for="descricao">Descrição da Despesa<span>*</span></label>
								<input type="text" name="descricao" id="descricao" placeholder="<?php echo $_SESSION['despesas']['descricao']; ?>" size="22" required>
							</div>
							<div class="one_half first">
								<label for="valor">Valor<span>*</span></label>
								<input type="number" name="valor" id="valor" placeholder="<?php echo $_SESSION['despesas']['valor']; ?>" size="22" required>
							</div>
							<div class="one_half">
								<div class=" styled-select black rounded">
									<label for="categoria">Categoria:</label>
									<select name="categoria">
									<?php 
									if(strtolower($_SESSION['despesas']['categoria']) == "compra"){
										echo "<option value='Compra' selected>Compra</option><option value='Venda'>Venda</option>";
										}
									if(strtolower($_SESSION['despesas']['categoria']) == "venda"){
										echo "<option value='Compra' >Compra</option><option value='Venda' selected>Venda</option>";
										}			
									?>
									</select> 
								</div>
							</div>
							<div class="one_half first">
								<label for="data_despesa">Data da Despesa<span>*</span></label>
								<input type="date" name="data_despesa" placeholder="<?php echo $_SESSION['despesas']['data']; ?>" id="data_despesa" size="22" required>
							</div>
							<div class="one_half">
								<label for="data_despesa_hora">Hora da Despesa<span>*</span></label>
								<input type="text" name="data_despesa_hora" id="data_despesa_hora" placeholder="<?php echo $_SESSION['despesas']['hora']; ?>" size="22" required>
							</div>
							<div class="one_half first">
								<input type="submit" name="submit" value="Enviar">
								&nbsp;
								<input type="reset" name="reset" value="Limpar">
							</div>
						</form>
					</div>
				</div>
			</main>
		</div>
		<?php

		// FOOTER CONTACT
		include_once("fragments/footer-contact.php");
		// FOOTER
		include_once("fragments/footer.php");

		?>
		<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
		<!-- JAVASCRIPTS -->
		<script src="layout/scripts/jquery.min.js"></script>
		<script src="layout/scripts/jquery.backtotop.js"></script>
		<script src="layout/scripts/jquery.mobilemenu.js"></script>
		<!-- IE9 Placeholder Support -->
		<script src="layout/scripts/jquery.placeholder.min.js"></script>
		<!-- Adição da classe ativa para pagina do menu -->
		<script>
		/*
		* Author: Eduardo Asafe
		* Data: 20/04/2017
		*/
		$("#mainav ul li:nth-child(5)").addClass("active");
		$(document).ready(function(){
			// Função responsável pela inserção do ':' quando o usuario digitar na caixa de data_despesa_hora.
			$("#data_despesa_hora").keyup(function(){
				var hora = '';
				var text = $("#data_despesa_hora").val();
				hora = hora + text;
				if(hora.length == 2 || hora.length == 5){
						hora = hora + ':';
						var text = $("#data_despesa_hora").val(hora);
				}
				if(hora.length == 8){
					verificaHora();
				}
			});
			
			// Função responsável pela inserção do '/' quando o usuario digitar na caixa_despesa.
			$("#data_despesa").keyup(function(){
				var data = '';
				var text = $("#data_despesa").val();
				data = data + text;
				if(data.length == 2 || data.length == 5){
						data = data + '/';
						var text = $("#data_despesa").val(data);
				}
			});
			
			// Função que verifica se a hora passada pelo usuario esta digitada de maneira correta. (HH:mm:ss)
			function verificaHora(){
				var hrs = ($("#data_despesa_hora").val().substring(0,2)); 
				var min = ($("#data_despesa_hora").val().substring(3,5));
				var seg = ($("#data_despesa_hora").val().substring(6,8));
				var estado = "";
				
				if ((hrs < 00 ) || (hrs > 23) || ( min < 00) || ( min > 59) || ( seg < 00) || ( seg > 59)){
					estado = "errada"; 
				}
				
				if ($("#data_despesa_hora").val() == "") { 
					estado = "errada"; 
				}

				if (estado == "errada") { 
					alert("Hora inválida!"); 
					$("#data_despesa_hora").focus(); 
					return false
				}
			}
			// Função que verifica se a data passada pelo usuario esta digitada de maneira correta. (dd/MM/yyyy)
			$("form").submit(function(){
				var data = $("#data_despesa").val();
				var dia = data.substring(0,2);
				var mes = data.substring(3,5);
				var ano = data.substring(6,10);
				
				var novaData = new Date(ano,(mes-1),dia);
				
				var mesmoDia = parseInt(dia,10) == parseInt(novaData.getDate());
				var mesmoMes = parseInt(mes,10) == parseInt(novaData.getMonth())+1;
				var mesmoAno = parseInt(ano) == parseInt(novaData.getFullYear());
				
				if (!((mesmoDia) && (mesmoMes) && (mesmoAno))){
					alert('Data informada é inválida!');   
					$("#data_despesa").focus();    
					return false;
				} 
				verificaHora();
				return true;
			
			});
		});
		</script>
	</body>
</html>