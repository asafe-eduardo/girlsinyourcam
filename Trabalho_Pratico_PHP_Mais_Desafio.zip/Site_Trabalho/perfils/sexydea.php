<?php

if(!isset($_SESSION)) session_start();

if(!isset($_SESSION['login']['auth'])) {
	session_destroy();
	
	header("Location: login.php");
}

?>
<!DOCTYPE html>
<!--
Template Name: Lacegant
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html>
	<head>
		<title>GYCam | Perfils</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<link href="../layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
		<link href="../layout/styles/style.css" rel="stylesheet" type="text/css" media="all">
	</head>
	<body id="top">
	<?php

		$pageName = "perfil";
		$urlimage = "background-image:url('../images/demo/backgrounds/02.jpg');";
		$home = "../home/home.php";
		$gallery = "../home/gallery.php";
		$contact = "../home/contact.php";
		$profile = "../home/profile.php";
		$despesas = "../despesas.php";
		$sair = "../home/sair.php";

		// HEADER
		include_once("../fragments/header.php"); 
		// MENU
		include_once("../fragments/menu.php"); 
		// 	LOCATION
		include_once("../fragments/location.php");
		// 	MENU COM AJAX
		include_once("../fragments/menu-ajax.php"); 

	?>
		<div class="wrapper row3">
			<main class="hoc container clear"> 
				<div class="content"> 
					<div class="content three_quarter"> 
						<h1>Sexydea</h1>
						<img class="imgr borderedbox inspace-5" src="../images/demo/sexydea.jpg" alt="">
						<p>As espanholas são conhecidas por serem extremamente "quentes", Sexydea não é excessão a regra.</p>
						<p>Seus videos contém desde sexo a "calças molhadas", se você ainda não viu provavelmente não sabe apreciar um bom webshow.</p>
					</div>
				</div>
				<div class="clear"></div>
			</main>
		</div>

	<?php

		// FOOTER CONTACT
		include_once("../fragments/footer-contact.php");
		// FOOTER
		include_once("../fragments/footer.php");

	?>
		<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
		<!-- JAVASCRIPTS -->
		<script src="../layout/scripts/jquery.min.js"></script>
		<script src="../layout/scripts/jquery.backtotop.js"></script>
		<script src="../layout/scripts/jquery.mobilemenu.js"></script>
		<!-- IE9 Placeholder Support -->
		<script src="../layout/scripts/jquery.placeholder.min.js"></script>
		<!-- Adição da classe ativa para pagina do menu -->
		<script>
			$("#mainav ul li:nth-child(1)").addClass("active");
			$(".menu-ajax ul li:nth-child(1)").removeClass("active");
			var navAnterior = $(".menu-ajax ul li:nth-child(2)").addClass("active");
			$(document).ready(function(){
				$(".menu-ajax ul li").click(function(){
					navAnterior.removeClass("active");
					navAnterior = $(this).addClass("active");
					var page = $(this).find("a").html();
					$.ajax({
					url: "frags/" + page + ".php",
					cache: false
					}).done(function(html){
					$(".row3").html(html);
					});
				});
			});
		</script>
		<script src="../layout/scripts/styles.js"></script>
	</body>
</html>