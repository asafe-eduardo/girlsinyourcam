
		<div class="wrapper row3">
			<main class="hoc container clear"> 
				<div class="content"> 
					<div class="content three_quarter"> 
						<h1>DariejXO</h1>
						<img class="imgr borderedbox inspace-5" src="../images/demo/dariejxo.jpg" alt="">
						<p>Não é segredo que as asiáticas contém um lugar todo especial nas fantasias sexuais masculinas, é por isso dariejXO conseguir conquistar seu espaço não só na internet mas, na vida de seus fãs.</p>
						<p>DariejXO ("XO" nas mensagens de texto que significa "beijo") além de linda tem muito apetite e quem acompanha seus vídeos sempre se apaixona.</p>
					</div>
				</div>
				<div class="clear"></div>
			</main>
		</div>
