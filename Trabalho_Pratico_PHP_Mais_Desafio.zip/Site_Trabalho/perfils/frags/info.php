
		<div class="wrapper row3">
			<main class="hoc container clear"> 
				<div class="content"> 
					<div class="content three_quarter"> 
						<h1>Não perca esta oportunidade</h1>
						<img class="imgr borderedbox inspace-5" src="../images/demo/320x220.png" alt="">
						<p>Se você é garota e está interessada em ganhar muito dinheiro não pode perder a chance de entrar para equipe da <a href="../home.php">GYCam</a>.</p>
						<p>Entre em <a href="../contact.php">contato</a> conosco preencha os campos corretamente e no tipo de mensagem escolha "<strong>Quero entrar no grupo</strong>" feito isso espere nosso email de resposta com mais informações.</p>
						<p>Se escolhida além de ocupar este perfil você entrará para o nosso seleto grupo de garotas onde só se encontra garotas veneradas por homens e invejada pelas mulheres.</p>
					</div>
				</div>
				<div class="clear"></div>
			</main>
		</div>
