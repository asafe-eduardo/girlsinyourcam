
		<div class="wrapper row3">
				<main class="hoc container clear"> 
					<div class="content"> 
						<div class="content three_quarter"> 
							<h1>Steph Kegels</h1>
							<img class="imgr borderedbox inspace-5" src="../images/demo/steph.jpg" alt="">
							<p>Steph kegels uma das melhores camgirls da atualidade fez sucesso pelos seus webshows numa biblioteca, além de seu grande "atributo" traseiro e bom humor.</p>
							<p>Com suas e webshows faz a alegria da "garotada" e domina as fantasias masculinas</p>
						</div>
					</div>
					<div class="clear"></div>
				</main>
		</div>
