
		<div class="wrapper row3">
			<main class="hoc container clear"> 
				<div class="content"> 
					<div class="content three_quarter"> 
						<h1>Sexydea</h1>
						<img class="imgr borderedbox inspace-5" src="../images/demo/sexydea.jpg" alt="">
						<p>As espanholas são conhecidas por serem extremamente "quentes", Sexydea não é excessão a regra.</p>
						<p>Seus videos contém desde sexo a "calças molhadas", se você ainda não viu provavelmente não sabe apreciar um bom webshow.</p>
					</div>
				</div>
				<div class="clear"></div>
			</main>
		</div>
