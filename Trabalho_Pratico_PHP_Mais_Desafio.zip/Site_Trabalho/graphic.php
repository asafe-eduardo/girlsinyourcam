<?php
	
	require "init.php";
	session_start();
	
	if(!isset($_SESSION)) session_start();

	if(!isset($_SESSION['login']['auth'])) {
		session_destroy();
	
		header("Location: login.php");
	}
	
	$Despesa = new Despesa;
    $array = $Despesa->retornaDespesas ($_SESSION['login']['id_usuario']);

?>
<!DOCTYPE html>
<!--
	Template Name: Lacegant
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html>
	<head>
		<title>GYCam | Grafico</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
		<link href="layout/styles/style.css" rel="stylesheet" type="text/css" media="all">
		<script src="layout/scripts/Chart.bundle.min.js"></script>
		<script src="layout/scripts/jquery-2.2.3.min.js"></script>
		<style>
			canvas{
				-moz-user-select: none;
				-webkit-user-select: none;
				-ms-user-select: none;
			}
		</style>
		</head>
		<body id="top">
		<?php

			$pageName = "Despesas > Gráfico";
			$urlimage = "background-image:url('images/demo/backgrounds/02.jpg');";
			
			$home = "home/home.php";
			$gallery = "home/gallery.php";
			$contact = "home/contact.php";
			$profile = "home/profile.php";
			$despesas = "despesas.php";
			$sair = "home/sair.php";

			// HEADER
			include_once("fragments/header.php"); 
			// MENU
			include_once("fragments/menu.php"); 
			// 	LOCATION
			include_once("fragments/location.php"); 

		?>
		<div class="wrapper row3">
			<main class="hoc container clear"> 
				<a class="btn" href="despesas.php">Voltar</a>
				<div class="content"> 
					<div style="width:100%;">
						<canvas id="canvas"></canvas>
					</div>
				</div>
			</main>
		</div>
	<?php

		// FOOTER CONTACT
		include_once("fragments/footer-contact.php");
		// FOOTER
		include_once("fragments/footer.php");

	?>
		<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
		<!-- JAVASCRIPTS -->
		<script src="layout/scripts/jquery.min.js"></script>
		<script src="layout/scripts/jquery.backtotop.js"></script>
		<script src="ayout/scripts/jquery.mobilemenu.js"></script>
		<!-- IE9 Placeholder Support -->
		<script src="layout/scripts/jquery.placeholder.min.js"></script>
		<!-- Adição da classe ativa para pagina do menu -->
		<script>
			$("#mainav ul li:nth-child(5)").addClass("active");
		</script>
		<script>
			var MONTHS = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
			var config = {
				type: 'line',
				data: {
					labels: ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"],
					datasets: [{
						label: "Compras",
						backgroundColor:  "rgba(0, 0, 255,0.5)",
						borderColor:  "rgba(0, 0, 255,0.5)",
						data: [<?php foreach($array["Compras"] as $compra){ echo $compra .",";}?>],
						fill: false,
					},  {
						fill: false,
						label: "Vendas",
						backgroundColor:  "rgba(255, 0, 0,0.5)",
						borderColor:  "rgba(255, 0, 0,0.5)",
						data: [<?php foreach($array["Vendas"] as $venda){ echo $venda .",";}?>],
					}]
				},
				options: {
					responsive: true,
					title:{
						display:true,
						text:'Balanço de Compras/Vendas - GYCam'
					},
					tooltips: {
						mode: 'label',
					},
					hover: {
						mode: 'dataset'
					},
					scales: {
						xAxes: [{
							display: true,
							scaleLabel: {
								show: true,
								labelString: 'Month'
							}
						}],
						yAxes: [{
							display: true,
							scaleLabel: {
								show: true,
								labelString: 'Value'
							},
						}]
					}
				}
			};
			window.onload = function() {
				var ctx = document.getElementById("canvas").getContext("2d");
				window.myLine = new Chart(ctx, config);
			};
		</script>
	</body>
</html>