<?php
	
	require "init.php";
	session_start();

	$titulo = isset ($_POST['titulo']) ? anti_injection ($_POST['titulo']) : NULL;
	$descricao = isset ($_POST['descricao']) ? anti_injection ($_POST['descricao']) : NULL;
	$valor = isset ($_POST['valor']) ? anti_injection ($_POST['valor']): NULL;
	$categoria = isset ($_POST['categoria']) ? anti_injection ($_POST['categoria']): NULL;
	$dataDespesa = isset ($_POST['data_despesa']) ? anti_injection ($_POST['data_despesa']): NULL;
	$horaDespesa = isset ($_POST['data_despesa_hora']) ? anti_injection ($_POST['data_despesa_hora']): NULL;
	
	$array = explode("/", $dataDespesa);
	$array = array_reverse($array);
	$dataDespesa = implode("-", $array);
	
	$hrs = substr($horaDespesa, 0,2);
	$min =  substr($horaDespesa, 3,2);
	$seg =  substr($horaDespesa, 6,2);
	
	if (($hrs < 00) || ($hrs > 23) || ( $min < 00) || ( $min > 59) || ( $seg < 00) || ( $seg > 59)){
		echo "<script type=\"text/javascript\">alert('Erro no formato do horario lembre-se de passara no formato hh:mm:ss');location.href = 'despesas.php';</script>";
	}
	
	$Despesa = new Despesa;
    $Despesa->InserirDespesas ($titulo, $descricao, $valor,$categoria, $dataDespesa, $horaDespesa, $_SESSION['login']['id_usuario']);
?>