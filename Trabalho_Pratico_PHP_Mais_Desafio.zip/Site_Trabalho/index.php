<!DOCTYPE html>
<!--
Template Name: Lacegant
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html>
	<head>
		<title>Girls In Your Cam</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
	</head>
	<body id="top">
		<?php

		// HEADER
		include_once("fragments/header.php"); 

		?>
		<div class="wrapper bgded overlay coloured" style="background-image:url('images/demo/backgrounds/02.jpg');">
			<div id="cta" class="hoc clear"> 
				<article class="center">
					<h2 class="heading font-x3">Atenção este site contém conteúdo proibido para menores de 18 anos</h2>
					<footer>
						<ul class="nospace inline pushright">
							<li><a class="btn inverse" href="../">Sou menor de 18</a></li>
							<li><a class="btn inverse" href="login.php">Sou maior de 18</a></li>
						</ul>
					</footer>
				</article>
			</div>
		</div>
		<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
		<!-- JAVASCRIPTS -->
		<script src="layout/scripts/jquery.min.js"></script>
		<script src="layout/scripts/jquery.backtotop.js"></script>
		<script src="layout/scripts/jquery.mobilemenu.js"></script>
		<!-- IE9 Placeholder Support -->
		<script src="layout/scripts/jquery.placeholder.min.js"></script>
		<!-- Adição da classe ativa para pagina do menu -->
		<script>
			$("#mainav ul li:nth-child(1)")
		</script>
	</body>
</html>