<?php
	
	require "init.php";
	
	$nome = isset ($_POST['nome']) ? anti_injection ($_POST['nome']) : NULL;
	$email = isset ($_POST['email']) ? anti_injection ($_POST['email']) : NULL;
	$login  = isset ($_POST['login']) ? anti_injection ($_POST['login']) : NULL;
	$senha1 = isset ($_POST['senha']) ? anti_injection ($_POST['senha']) : NULL;
	$senha2 = isset ($_POST['re-senha']) ? anti_injection ($_POST['re-senha']) : NULL;
	$dicaSenha = isset ($_POST['dica-senha']) ? anti_injection ($_POST['dica-senha']) : NULL;
	
	$Login = new Login;
	$Login->RegistrarUsuario ($nome, $email, $login, $senha1, $senha2,$dicaSenha);
	
?>