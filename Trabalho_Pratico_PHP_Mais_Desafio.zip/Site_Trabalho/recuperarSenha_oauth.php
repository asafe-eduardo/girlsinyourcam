<?php
	
	require "init.php";
	session_start();

	$email = isset ($_POST['email']) ? anti_injection ($_POST['email']) : NULL;
	$dicaSenha = isset ($_POST['dica-senha']) ?anti_injection ($_POST['dica-senha']) : NULL;
	
	$Login = new Login;
	$Login->RecuperarSenha ($email, $dicaSenha);
?>