<?php
	
	require "init.php";
	session_start();

	$user = isset ($_POST['login']) ? anti_injection ($_POST['login']) : NULL;
	$senha = isset ($_POST['senha']) ? md5 (anti_injection ($_POST['senha'])) : NULL;
	
	$Login = new Login;
	$Login->AutenticarUsuario ($user, $senha);
?>