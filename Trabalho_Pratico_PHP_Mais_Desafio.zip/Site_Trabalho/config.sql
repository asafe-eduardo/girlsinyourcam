-- phpMyAdmin SQL Dump
-- version 4.6.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 20-Abr-2017 às 20:19
-- Versão do servidor: 5.7.13
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `GYBase`
--
CREATE DATABASE IF NOT EXISTS gybase DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE gybase;

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE usuarios (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL,
  `login` varchar(32) NOT NULL,
  `dica_senha` varchar(255) NOT NULL,
  `senha` varchar(255) NOT NULL,
	PRIMARY KEY (`id`),
	UNIQUE KEY (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Estrutura da tabela `despesas`
--

CREATE TABLE `despesas` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) NOT NULL, 
  `descricao` varchar(255) NOT NULL,
  `valor` double(10,3) NOT NULL,
  `categoria` varchar(255) NOT NULL,
  `data_despesa` DATE NOT NULL,
  `data_despesa_hora` DATETIME NOT NULL,
  `id_usuario` int(10) NOT NULL,
	FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
	ON DELETE RESTRICT ON UPDATE CASCADE,
	PRIMARY KEY (`id`, `id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Inserindo valores na tabela `usuarios`
--

INSERT INTO `usuarios` VALUES  (NULL, 'Administrador', 'admin@email.com', 'admin', '123', '202cb962ac59075b964b07152d234b70');

--
-- Inserindo valores na tabela `despesas` (meramente artificiais)
--

INSERT INTO `despesas` VALUES  (NULL, 'Compra de Gycoins', 'Comprei gycoins! :D', 1000, 'Compra', '2017-01-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Compra de Gycoins', 'Comprei gycoins! :D', 2000, 'Compra', '2017-02-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Compra de Gycoins', 'Comprei gycoins! :D', 4000, 'Compra', '2017-03-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Compra de Gycoins', 'Comprei gycoins! :D', 8000, 'Compra', '2017-04-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Compra de Gycoins', 'Comprei gycoins! :D', 10000, 'Compra', '2017-05-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Compra de Gycoins', 'Comprei gycoins! :D', 12000, 'Compra', '2017-06-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Compra de Gycoins', 'Comprei gycoins! :D', 10000, 'Compra', '2017-07-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Compra de Gycoins', 'Comprei gycoins! :D', 8000, 'Compra', '2017-08-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Compra de Gycoins', 'Comprei gycoins! :D', 4000, 'Compra', '2017-09-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Compra de Gycoins', 'Comprei gycoins! :D', 2000, 'Compra', '2017-10-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Compra de Gycoins', 'Comprei gycoins! :D', 1000, 'Compra', '2017-11-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Compra de Gycoins', 'Comprei gycoins! :D', 0, 'Compra', '2017-12-01', '00:00:00',1);

INSERT INTO `despesas` VALUES  (NULL, 'Venda de Gycoins', 'Comprei o show da steph', 0, 'Venda', '2017-01-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Venda de Gycoins', 'Comprei o show da sexydea', 0, 'Venda', '2017-02-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Venda de Gycoins', 'Comprei o show da dariejxo', 3000, 'Venda', '2017-03-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Venda de Gycoins', 'Comprei o show da steph', 6000, 'Venda', '2017-04-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Venda de Gycoins', 'Comprei o show da steph', 8000, 'Venda', '2017-05-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Venda de Gycoins', 'Comprei o show da dariejxo', 5000, 'Venda', '2017-06-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Venda de Gycoins', 'Comprei o show da sexydea', 7000, 'Venda', '2017-07-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Venda de Gycoins', 'Comprei o show da sexydea', 9000, 'Venda', '2017-08-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Venda de Gycoins', 'Comprei o show da dariejxo', 5000, 'Venda', '2017-09-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Venda de Gycoins', 'Comprei o show da dariejxo', 4000, 'Venda', '2017-10-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Venda de Gycoins', 'Comprei o show da steph', 2000, 'Venda', '2017-11-01', '00:00:00',1);
INSERT INTO `despesas` VALUES  (NULL, 'Venda de Gycoins', 'Comprei o show da steph', 3000, 'Venda', '2017-12-01', '00:00:00',1);