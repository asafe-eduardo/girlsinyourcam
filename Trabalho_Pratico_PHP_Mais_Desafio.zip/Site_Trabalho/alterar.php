<?php
	
	require "init.php";
	
	$nome = isset ($_POST['nome']) ? anti_injection ($_POST['nome']) : NULL;
	$email = isset ($_POST['email']) ? anti_injection ($_POST['email']) : NULL;
	$login  = isset ($_POST['login']) ? anti_injection ($_POST['login']) : NULL;
	$senha1 = isset ($_POST['senha']) ? anti_injection ($_POST['senha']) : NULL;
	$senha2 = isset ($_POST['re-senha']) ? anti_injection ($_POST['re-senha']) : NULL;
	$dicaSenha = isset ($_POST['dica-senha']) ? anti_injection ($_POST['dica-senha']) : NULL;
	
	$Login = new Login;
	$Login->AlterarUsuario ($nome, $email, $login, $senha1, $senha2,$dicaSenha);
	
	
?>
<!DOCTYPE html>
<!--
Template Name: Lacegant
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html>
	<head>
		<title>GYCam | Alterar</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
	</head>
	<body id="top">
		<?php

		// HEADER
		include_once("fragments/header.php"); 

		?>
		<div class="wrapper bgded overlay coloured" style="background-image:url('images/demo/backgrounds/02.jpg');">
			<div id="cta" class="hoc clear"> 
				<article class="center">
					<h6 class="heading font-x3">Seus dados foram alterados com sucesso!</h6>
					<footer>
						<p>Clique no botão abaixo para fazer o login</p>
						<ul class="nospace inline pushright">
							<li><a class="btn inverse" href="home/sair.php">Login</a></li>
						</ul>
					</footer>
				</article>
			</div>
		</div>
		<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
		<!-- JAVASCRIPTS -->
		<script src="layout/scripts/jquery.min.js"></script>
		<script src="layout/scripts/jquery.backtotop.js"></script>
		<script src="layout/scripts/jquery.mobilemenu.js"></script>
		<!-- IE9 Placeholder Support -->
		<script src="layout/scripts/jquery.placeholder.min.js"></script>
		<!-- Adição da classe ativa para pagina do menu -->
		<script>
			$("#mainav ul li:nth-child(1)")
		</script>
	</body>
</html>